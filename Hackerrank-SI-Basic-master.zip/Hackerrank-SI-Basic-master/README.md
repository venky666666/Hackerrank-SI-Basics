# Hackerrank-SI-Basic
My submissions for Hackerrank Smart Interviews' (BASIC).

These are my submissions for Hackerrank Smart Interviews (BASIC); https://www.hackerrank.com/contests/smart-interviews-basic/challenges 
Most of them are in Python but some (for which either Python is running slow, or the solution is easy in C) are in C.
