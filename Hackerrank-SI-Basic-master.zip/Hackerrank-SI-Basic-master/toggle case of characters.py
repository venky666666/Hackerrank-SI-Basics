'''
Given a string, toggle case of each character in the given string.

Input Format

Input contains a string - S.

Constraints

1 <= len(S) <= 100

Output Format

Print the toggled string.

Sample Input 0

abdBd
Sample Output 0

ABDbD
Explanation 0

Self Explanatory
'''

s=str(input())
print(s.swapcase())
