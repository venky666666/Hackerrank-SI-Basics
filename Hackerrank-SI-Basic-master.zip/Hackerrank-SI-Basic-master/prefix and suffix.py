#YET TO BE DONE

'''
Given a string, compute the length of longest prefix string which is same as the suffix of the string, the length of the prefix or suffix string must be less than the given input string.

Input Format

Input contains a string - S.

Constraints

1 <= len(S) <= 100

Output Format

Print length of longest prefix string which is same as suffix of the string.

Sample Input 0

smartintsmart
Sample Output 0

5
Explanation 0

Self Explanatory
'''

